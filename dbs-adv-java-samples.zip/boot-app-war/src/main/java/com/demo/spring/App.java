package com.demo.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class App extends SpringBootServletInitializer{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		System.out.println("I am from Configure...");
		return builder.sources(App.class);
	}
	
	
	public static void main(String[] args) {
		
		System.out.println("I am from Configure...");
		SpringApplication.run(App.class, args);
	}

}
