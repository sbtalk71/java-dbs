package criteria;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;

import com.demo.entity.Emp;

public class Query1 {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			
			//Criteria crit=session.createCriteria(Emp.class).add(Restrictions.between("salary", 25000.0, 80000.0));
			
			Criteria crit=session.createCriteria(Emp.class).setProjection(
					Projections.projectionList()
					.add(Projections.property("empId"))
					.add(Projections.property("name"))
					.add(Projections.property("salary")));
			
			
			/*
			 * for(Emp e:empList) {
			 * System.out.println(e.getEmpId()+" "+e.getName()+" "+e.getSalary()); }
			 */
			
			List<Object[]> empList=crit.list();
			
			for(Object[] o:empList) {
				Integer id=(Integer)o[0];
				String name=(String)o[1];
				Double salary=(Double)o[2];
				System.out.println(id+" "+name+" "+salary);
			}
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
