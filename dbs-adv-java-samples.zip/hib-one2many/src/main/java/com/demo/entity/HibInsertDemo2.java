package com.demo.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibInsertDemo2 {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			
			
			Dept d=session.load(Dept.class, 30);
			
			Emp e = new Emp(115, "Ankit", "Hyderabad", 66000);
			d.getEmps().add(e);
			
			
			Emp e1 = new Emp(116, "Bhim", "Bangalore", 76000);
			
			d.getEmps().add(e1);
			
			session.saveOrUpdate(e1);
			
			session.flush();
			tx.commit();
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
