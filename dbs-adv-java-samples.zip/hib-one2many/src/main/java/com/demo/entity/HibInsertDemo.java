package com.demo.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibInsertDemo {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			
			
			Dept d=session.load(Dept.class, 20);
			
			Emp e = new Emp(115, "Ankit", "Hyderabad", 66000);
			e.setDept(d);
			session.save(e);
			
			
			Emp e1 = new Emp(116, "Bhim", "Bangalore", 76000);
			e1.setDept(d);
			session.save(e1);
			
			session.flush();
			tx.commit();
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
