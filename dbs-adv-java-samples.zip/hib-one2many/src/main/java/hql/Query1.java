package hql;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.entity.Emp;

public class Query1 {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			
			Query query=session.createQuery("from Emp e");
			//Query query=session.createQuery("from Emp e where e.salary between 45000 and 70000");
			
			List<Emp> empList=query.list();
			/*
			 * for(Emp e:empList) {
			 * System.out.println(e.getEmpId()+" "+e.getName()+" "+e.getSalary()); }
			 */
			empList.parallelStream().forEach(e->System.out.println(e.getEmpId()+" "+e.getName()+" "+e.getSalary()));
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
