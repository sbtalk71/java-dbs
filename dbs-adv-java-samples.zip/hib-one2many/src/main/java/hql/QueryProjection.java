package hql;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.demo.entity.Emp;

public class QueryProjection {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			
			//Query query=session.createQuery("from Emp e");
			//Query query=session.createQuery("select e.name,e.salary from Emp e where e.salary between :x1 and :x2");
			//query.setString("x1","40000");
			//query.setString("x2","80000");
			
			Query query=session.createQuery("select e.name,e.salary from Emp e where e.salary between ? and ?");
			query.setString(0,"40000");
			query.setString(1,"80000");
			
			List<Object[]> empList=query.list();
			for(Object[] o:empList) {
				String name=(String)o[0];
				Double salary=(Double)o[1];
				System.out.println(name+" "+salary);
			}
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
