package com.demo.spring;

import java.util.ArrayList;
import java.util.List;

public class EmpDetails {
	private String empName;
	private int empId;
	private List<String> addresses=new ArrayList<>();
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public List<String> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<String> addresses) {
		this.addresses = addresses;
	}
	
}
