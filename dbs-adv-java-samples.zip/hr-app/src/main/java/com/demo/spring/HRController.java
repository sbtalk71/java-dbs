package com.demo.spring;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.demo.entity.Address;
import com.demo.entity.Emp;

@RestController
public class HRController {

	@GetMapping(path="/hr/get/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getEmpdetails(@PathVariable("id")int id) {
		RestTemplate rt = new RestTemplate();
		HttpHeaders headers=new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		
		HttpEntity reqData=new HttpEntity(headers);
		ResponseEntity<Emp> response=rt.exchange("http://localhost:8080/emp/find/"+id, 
				HttpMethod.GET, reqData, Emp.class);
		
		EmpDetails empDetails=new EmpDetails();
		Emp e=response.getBody();
		empDetails.setEmpId(e.getEmpId());
		empDetails.setEmpName(e.getName());
		
		for(Address ad: e.getAddresses()) {
			empDetails.getAddresses().add(ad.getDoorNo()+" "+ad.getCity()+" "+ad.getPinCode());
		}
		
		return ResponseEntity.ok(empDetails);
	}
}
