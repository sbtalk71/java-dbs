package com.demo.spring.rest;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.spring.entity.Emp;

@RestController
public class TestController {
	@Autowired
	private EntityManager em;

	//@RequestMapping(path="/greet/{n}",method = RequestMethod.GET)
	@GetMapping(path="/greet/{n}")
	public ResponseEntity<String> greet(@PathVariable("n")String name) {
		return ResponseEntity.ok(name+ ", Welcome to Spring REST");
	}
	
	@GetMapping(path="/emp1/find/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getEmp(@PathVariable("id")int id) {
		Emp e=em.find(Emp.class, id);
		//e.getEmpId();
		if(e!=null) {
			return ResponseEntity.ok(e);
		}else {
			return ResponseEntity.ok("Employee Not Found");
		}
	}
}
