package com.demo.spring.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import sun.security.util.ObjectIdentifier;

@Entity
@Table(name="MYDEPT")

@NamedQueries({
	@NamedQuery(name="query2",query="select e from Emp e"),
	
})

@NamedNativeQueries({
	@NamedNativeQuery(name="sqlQuery1",query="select e.empno,e.name,e.address,e.salary,d.dno,d.manager,d.dname"
			+ " from myemp e inner join mydept d on e.dno=d.dno",resultClass = Emp.class),
	@NamedNativeQuery(name="sqlQuery2",query="select e.name,e.salary from myemp e")
})
//@JsonIdentityInfo(property = "deptNo",generator = ObjectIdGenerators.PropertyGenerator.class)
public class Dept {
	@Id
	@Column(name="DNO")
	private int deptNo;
	
	@Column(name="MANAGER")
	private String manager;
	
	@Column(name="DNAME")
	private String deptName;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name="DNO")
	@JsonManagedReference
	private Set<Emp> emps=new HashSet<>();

	public Set<Emp> getEmps() {
		return emps;
	}

	public void setEmps(Set<Emp> emps) {
		this.emps = emps;
	}

	public Dept() {
		// TODO Auto-generated constructor stub
	}

	public Dept(int deptNo, String manager, String deptName) {
		this.deptNo = deptNo;
		this.manager = manager;
		this.deptName = deptName;
	}

	public int getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

}
