package com.demo.spring.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "MYEMP")
//@JsonIdentityInfo(property = "empId",generator = ObjectIdGenerators.PropertyGenerator.class)
@XmlRootElement
public class Emp {

	@Id
	@Column(name = "EMPNO")
	private int empId;

	@Column(name = "NAME")
	private String name;

	@ElementCollection
	@JoinTable(name="ADDRESSES",joinColumns = {@JoinColumn(name="EMPNO")})
	private Set<Address> addresses=new HashSet<>();

	@Column(name = "SALARY")
	private double salary;

	//@ManyToOne
	//@JoinColumn(name = "DNO")
	//@JsonBackReference
	/*
	 * private Dept dept;
	 * 
	 * public Dept getDept() { return dept; }
	 * 
	 * public void setDept(Dept dept) { this.dept = dept; }
	 */

	public Emp() {
		// TODO Auto-generated constructor stub
	}

	public Emp(int empId, String name, double salary) {
		this.empId = empId;
		this.name = name;
		this.salary = salary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Set<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Set<Address> addresses) {
		this.addresses = addresses;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}
