package com.demo.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPAQueryMain {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqldb");
		EntityManager em = emf.createEntityManager();

		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();
			System.out.println("============First Query=============");
			Query query = em.createQuery("select e from Emp e where e.salary between 30000 and 80000");
			List<Emp> empList = query.getResultList();

			for (Emp e : empList) {
				System.out.println(
						e.getEmpId() + " " + e.getName() + " " + e.getSalary() + " " + e.getDept().getDeptName());
			}

			System.out.println("============Seconed Query=============");
			Query query2 = em.createNamedQuery("sqlQuery1");

			List<Emp> empList2 = query2.getResultList();
			for (Emp e : empList2) {
				System.out.println(
						e.getEmpId() + " " + e.getName() + " " + e.getSalary() + " " + e.getDept().getDeptName());
			}

			System.out.println("============Third Query=============");

			Query query3 = em.createNamedQuery("sqlQuery2");

			List<Object[]> empList3 = query3.getResultList();
			for (Object[] e : empList3) {
				String name = (String) e[0];
				Double salary = (Double) e[1];
				System.out.println(name + " " + salary);
			}
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
			emf.close();
		}

	}

}
