package com.demo.web;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/controller")
public class EmpAppController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	static HashMap<Integer, Emp> empDb = new HashMap<>();

	@Override
	public void init(ServletConfig config) throws ServletException {
		empDb.put(100, new Emp(100, "Karan", "Bangalore", 56000));
		empDb.put(101, new Emp(101, "Charan", "Hyderabad", 56000));
		empDb.put(102, new Emp(102, "Pavan", "Hyderabad", 56000));
		empDb.put(103, new Emp(103, "Manoj", "Hyderabad", 56000));
		empDb.put(104, new Emp(104, "Raja", "Chennai", 56000));
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String target=request.getParameter("target");
		
		if(target.equals("register")) {
			request.getRequestDispatcher("/registerEmp.jsp").forward(request, response);
		}
		else if(target.equals("save")) {
			String empId=request.getParameter("empId");
			String name=request.getParameter("name");
			String city=request.getParameter("city");
			String salary=request.getParameter("salary");
			int id=Integer.parseInt(empId);
			double sal=Double.parseDouble(salary);
			if(empDb.containsKey(id)) {
				request.getRequestDispatcher("/registerFailed.jsp").forward(request, response);;
			}else {
				empDb.put(id, new Emp(id, name, city, sal));
				request.setAttribute("ename", name);
				request.getRequestDispatcher("/registerSuccess.jsp").forward(request, response);
			}
		}
	}

}
