package com.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TRAINEE")

public class TraineeEmp extends Employee {

	private String performance;

	public TraineeEmp() {
		// TODO Auto-generated constructor stub
	}

	public TraineeEmp(int id, String name, double salary, String perf) {
		super(id, name, salary);
		this.performance = perf;

	}

	public String getPerformance() {
		return performance;
	}

	public void setPerformance(String performance) {
		this.performance = performance;
	}

}
