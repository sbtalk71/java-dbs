package com.demo.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibInsertDemo {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			Person p=new Person(1, "Scott");
			Employee e= new Employee(2, "Kiran", 56000);
			TraineeEmp te=new TraineeEmp(3, "Charan", 45000, "good");
			
			session.persist(p);
			session.persist(e);
			session.persist(te);
			tx.commit();
		
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
