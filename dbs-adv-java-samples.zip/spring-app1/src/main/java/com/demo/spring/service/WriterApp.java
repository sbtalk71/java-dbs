package com.demo.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.spring.Writer;

@Service
public class WriterApp {

	@Autowired
	@Qualifier("decoratedWriter")
	private Writer writer;

	public void print(String message) {
		writer.write(message);
	}
}
