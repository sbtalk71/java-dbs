package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.service.WriterApp;

public class AppMain {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//WriterApp app=(WriterApp)ctx.getBean("writerApp");
		
		WriterApp app=ctx.getBean(WriterApp.class);
		
		app.print("Hello There!");

	}

}
