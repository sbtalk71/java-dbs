package com.demo.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String city = request.getParameter("city");
		if (city.equalsIgnoreCase("hyderabad")) {
			RequestDispatcher rd = request.getRequestDispatcher("/s3");
			rd.forward(request, response);
		} else if (city.equalsIgnoreCase("Bangalore")) {
			RequestDispatcher rd = request.getRequestDispatcher("/s2");
			rd.forward(request, response);
		} else if (!city.equalsIgnoreCase("Bangalore") || !city.equalsIgnoreCase("Hyderabad")) {
			response.sendRedirect("nocity.jsp");
			;
		}

	}

}
