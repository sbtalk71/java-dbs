package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Address {

	@Column(name="DOOR_NO")
	private String doorNo;
	
	@Column(name="CITY")
	private String city;
	
	@Column(name="PIN")
	private int pinCode;

	public Address(String doorNo, String city, int pinCode) {
		this.doorNo = doorNo;
		this.city = city;
		this.pinCode = pinCode;
	}

	public Address() {
		// TODO Auto-generated constructor stub
	}

	public String getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

}
