package com.demo.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibInsertDemo {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		try {
			
			Address addr1=new Address("1-2-122/10", "Hyderabad", 500016);
			Emp e = new Emp(101, "Ankit", addr1, 66000);
			e.getImages().add("front.jpg");
			e.getImages().add("left.jpg");
			e.getImages().add("right.jpg");
			e.getImages().add("profile.jpg");
			session.save(e);
			
			Address addr2=new Address("10-2-102/10", "Delhi", 500016);
			Emp e1 = new Emp(102, "Bhim", addr2, 76000);
			e1.getImages().add("front.jpg");
			e1.getImages().add("left.jpg");
			e1.getImages().add("right.jpg");
			e1.getImages().add("profile.jpg");
			session.save(e1);
			session.flush();
			tx.commit();
			
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			sf.close();
		}

	}

}
