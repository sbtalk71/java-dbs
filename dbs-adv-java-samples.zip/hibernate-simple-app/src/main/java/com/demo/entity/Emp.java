package com.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

@Entity
@Table(name="TESTEMP")
public class Emp {

	@Id
	@Column(name="EMPNO")
	private int empId;
	
	@Column(name="NAME")
	private String name;
	
	@Embedded
	private Address address;
	
	@Column(name="SALARY")
	private double salary;
	
	@ElementCollection
	@JoinTable(name = "IMAGES",joinColumns = @JoinColumn(name="EMPNO"))
	
	private Set<String> images=new HashSet<String>();
	
	  public Set<String> getImages() {
		return images;
	}


	public void setImages(Set<String> images) {
		this.images = images;
	}


	public Emp() { 
		  // TODO Auto-generated constructor stub 
	  }
	 

	public Emp(int empId, String name, Address address, double salary) {
		this.empId = empId;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
